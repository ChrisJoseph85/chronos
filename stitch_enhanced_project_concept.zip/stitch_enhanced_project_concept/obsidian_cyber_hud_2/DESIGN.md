---
name: Obsidian Cyber-HUD
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#89ceff'
  on-secondary: '#00344d'
  secondary-container: '#00a2e6'
  on-secondary-container: '#00344e'
  tertiary: '#a8ffd2'
  on-tertiary: '#003824'
  tertiary-container: '#5be9ad'
  on-tertiary-container: '#006645'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  display-md:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  headline-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
  mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  mono-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 1.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an ultra-refined, futuristic command cockpit engineered for deep work, cognitive flow, and offline-first personal time telemetry. The visual language bridges high-end tactical flight decks and sleek developer environments. It replaces clunky retro-terminal tropes with sharp, layered glassmorphic panels, precise optical lines, deep midnight voids, and high-frequency luminescent cyan telemetry indicators.

The aesthetic philosophy centers on:
- **Quiet Dominance:** A pitch-black foundation that eliminates sensory fatigue and puts the user in state of sustained hyper-focus.
- **Instrument Precision:** Every border, divider, and container feels micro-machined and deliberate. Glowing accents exist strictly to convey hierarchy, activity, and temporal context rather than decorative clutter.
- **Glass & Luminescence:** Translucent obsidian panels with razor-thin specular edges float over deep atmospheric gradients, evoking an elevated high-tech terminal designed for speed and tactical execution.

## Colors

The chromatic structure is built upon an intentional contrast between abyssal obsidian depths and sharp quantum photonics:

- **Primary (`#00E5FF`):** Electric Cyan. Dedicated to focal interactions, active states, real-time timer counters, selection rings, and dominant metric indicators.
- **Secondary (`#0EA5E9`):** Neon Azure. Provides atmospheric gradient ramps, secondary active tabs, structural highlights, and interactive hover states.
- **Tertiary (`#10B981`):** Quantum Emerald. Used for completed states, healthy offline local-storage sync status, and success metrics.
- **Alert / Warning (`#F59E0B` / `#EF4444`):** Solar Amber for non-blocking local discrepancies or connection warnings, and Laser Crimson for system exceptions.
- **Base & Surfaces:**
  - `canvas-root`: `#05080F` (abyssal canvas)
  - `surface-base`: `#090D16` (sidebar and primary layout anchor)
  - `surface-deck`: `#0D1527` (card base and module containers)
  - `surface-elevated`: `rgba(15, 23, 42, 0.65)` (glass backplanes with optical blurs)
- **Borders & Dividers:** `rgba(14, 165, 233, 0.16)` default ghost rim, stepping up to `rgba(0, 229, 255, 0.45)` upon hover or focus.
- **Typography Tone:** High-contrast ice-white (`#F8FAFC`) for primary headers and live telemetry, slate silver (`#94A3B8`) for body metadata, and muted slate (`#475569`) for inactive legends.

## Typography

The typography couples the modern legibility of **Inter** for navigational hierarchy and content digestion with the tabular precision of **JetBrains Mono** for numerical readouts, calendar indices, dates, logs, and system badges.

- **Headlines & Section Titles:** Rendered in Inter with tight letter-spacing (`-0.02em`) to produce a sleek, architectural presence.
- **Data & Telemetry:** Every numerical display—including stopwatches, time counters, node identifiers, dates, and status codes—strictly leverages JetBrains Mono with tabular numbers (`tnum`) enabled to prevent layout jitter during dynamic ticks.
- **Section Headers & Eyebrows:** Capitalized label styles with wide tracking (`+0.08em`) to mimic tactical instrumentation readouts.

## Layout & Spacing

The viewport implements a modular desktop command layout composed of three primary structural zones:

1. **Global Deck Rail (Fixed Left Navigation):** Standard width of `240px` (collapsible to `64px` icon-only mode) providing instant vertical routing.
2. **Dynamic Operations Canvas:** Fluid multi-column workspace partitioning tasks into primary dashboards (calendar arrays, session consoles) and secondary inspector side-cards (nodes, tags, summaries).
3. **Command & Omnibar Dock:** Bottom-docked console bar floating with persistent safe-margin clearance for instant global capture, voice prompt status, and system error feedback.

**Spacing Rhythm:**
All internal component padding, telemetry grid gaps, and control alignments conform strictly to a base 4px/8px rhythm. Panel cards maintain `1.25rem` (`space-lg`) internal breathing room, while micro-controls and calendar day cells preserve tight, dense `0.5rem` (`space-sm`) gaps to sustain maximum information density without visual crowding.

## Elevation & Depth

Visual hierarchy does not rely on heavy muddy drop shadows. Instead, it utilizes translucent optical layering, specularity, and directed photons:

- **Level 0 (Root Deck):** Solid `#05080F` canvas interspersed with a subtle radial gradient emanating from the top left corner (`rgba(0, 229, 255, 0.04)` fading into total darkness).
- **Level 1 (Panels & Card Modules):** Translucent backdrop (`rgba(13, 21, 39, 0.7)`) treated with `backdrop-filter: blur(16px)` and bounded by a 1px composite border (`rgba(255, 255, 255, 0.06)` top/left highlight, `rgba(14, 165, 233, 0.14)` base border).
- **Level 2 (Active/Hover Cards & Popovers):** Elevated surface (`rgba(17, 28, 51, 0.88)`), border stepping to `rgba(0, 229, 255, 0.35)` with an ambient cyan edge cast: `box-shadow: 0 0 24px -4px rgba(0, 229, 255, 0.12), 0 8px 32px rgba(0, 0, 0, 0.5)`.
- **Level 3 (Focused Controls & Active Timers):** High-energy glow state: dual-layer halo consisting of an inner crisp line and an external Gaussian bloom `0 0 16px rgba(0, 229, 255, 0.45)`.

## Shapes

The design uses a refined, compact radius (`roundedness: 1` — 4px base, 8px for containers, 12px for modal surfaces) to achieve an engineered, instrument-grade silhouette. Rounding is never bulbous or toy-like; corners feel precision-milled.

- **Primary Cards & Modules:** 8px (`0.5rem`) border radius, ensuring clean structural alignment when grouped in multi-card grids.
- **Interactive Inputs, Badges & Small Buttons:** 4px (`0.25rem`) border radius, maximizing touch/click targets while maintaining angular cohesion.
- **Calendar Matrix Cells:** 6px border radius, allowing clean separation between active, idle, and out-of-month dates.
- **Command Omnibar Dock:** 10px border radius, distinguishing it as an overlay device hovering above the static canvas.

## Components

### 1. Buttons & Tactical Triggers
- **Primary Glow Action (e.g., Start, Send):** Filled with solid `#00E5FF` foregrounded with `#05080F` ultra-dark bold text. Emits an ambient cyan glow (`0 0 16px rgba(0, 229, 255, 0.35)`). Active click states scale to `0.98` with enhanced contrast.
- **Secondary Ghost Controls (e.g., Load Nodes, Today, Mode Toggles):** Background `rgba(14, 165, 233, 0.08)`, border `1px solid rgba(14, 165, 233, 0.3)`. Text color `#38BDF8`. On hover, border shifts to `#00E5FF`, background brightens to `rgba(0, 229, 255, 0.16)`.
- **Destructive/Stop Triggers:** Tinted crimson ghost frame (`rgba(239, 68, 68, 0.15)` border) with subtle scarlet backplane glow on hover.

### 2. Form Inputs & Search Deck
- **Input Fields (Omnibar, Labels, Node Selectors):** Background `#090D16` with an inset micro-shadow. Border `1px solid rgba(30, 41, 59, 0.8)`. Placeholder text in muted `#475569`.
- **Focus State:** Border sharply transitions to `#00E5FF` accompanied by a localized inner glow (`box-shadow: inset 0 0 8px rgba(0, 229, 255, 0.15)`).

### 3. Checkboxes & Mode Selectors
- **Toggles / Segmented Controls:** Encased in a sunken dark chassis (`#080C14`), active pill shifts smoothly with `background: rgba(14, 165, 233, 0.2)` and a top border highlight.
- **Checkboxes:** Custom 16x16 square with 2px corner radius. Inactive: dark fill with slate border. Checked: `#00E5FF` neon check with faint luminous halo.

### 4. Interactive Calendar Deck
- **Grid Structure:** Strict 7-column grid layout with subtle 1px dividers between cells.
- **Day Cells:** JetBrains Mono numbers. Selected active day features an electric cyan outline box, subtle cyan linear-gradient backfill, and a glowing node indicator dot. Idle days display dim slate typography with zero-latency hover highlight.

### 5. Console & Status Feedbacks
- **Telemetry Banners (Error / Sync):** Minimalist horizontal strips. Error state features an amber/red border with dark obsidian interior, displaying monospaced status codes (`HTTP 401`, `LOCAL_STORAGE_OK`) paired with crisp micro-icons.
- **Sidebar Navigation Links:** Transparent background with left-edge indicator notch. When active, displays a full cyan boundary pill with an ethereal radial gradient bloom from the left edge (`rgba(0, 229, 255, 0.15)`).