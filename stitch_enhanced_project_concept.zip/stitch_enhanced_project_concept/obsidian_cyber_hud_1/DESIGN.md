---
name: Obsidian Cyber-HUD
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#d2c5ae'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#9b8f7b'
  outline-variant: '#4f4635'
  surface-tint: '#f4bf41'
  primary: '#ffe0a4'
  on-primary: '#402d00'
  primary-container: '#f5c042'
  on-primary-container: '#6b4f00'
  inverse-primary: '#795900'
  secondary: '#bdf4ff'
  on-secondary: '#00363d'
  secondary-container: '#00e3fd'
  on-secondary-container: '#00616d'
  tertiary: '#ffdbde'
  on-tertiary: '#670020'
  tertiary-container: '#ffb4bc'
  on-tertiary-container: '#a9003a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdf9e'
  primary-fixed-dim: '#f4bf41'
  on-primary-fixed: '#261a00'
  on-primary-fixed-variant: '#5b4300'
  secondary-fixed: '#9cf0ff'
  secondary-fixed-dim: '#00daf3'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#004f58'
  tertiary-fixed: '#ffd9dc'
  tertiary-fixed-dim: '#ffb2ba'
  on-tertiary-fixed: '#400011'
  on-tertiary-fixed-variant: '#910030'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
  gold-dim: '#e5a93b'
  gold-glow: rgba(245, 192, 66, 0.35)
  cyan-core: '#00e5ff'
  cyan-dim: '#0ea5e9'
  crimson-core: '#ff3366'
  crimson-glow: rgba(255, 51, 102, 0.35)
  obsidian-base: '#0a0e17'
  obsidian-deck: '#0f131c'
  obsidian-elevated: '#181b25'
  obsidian-border: rgba(245, 192, 66, 0.18)
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
  mono-xl:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  mono-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 1.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system defines an upgraded, tactical aerospace cyber-deck engineered for high-throughput operational intelligence, cognitive focus, and mission telemetry. Merging darkroom terminal ergonomics with futuristic HUD glasswork, the environment places cybernetic gold at its operational core, backed by electric cyan and laser crimson telemetry vectors.

The aesthetic philosophy centers on:
- **Warm Cybernetics & Tactical Prestige:** Warm amber-gold replaces stark monochromatic illumination, imbuing primary actions, system locks, and focus states with the warmth of high-energy photonics and aerospace brass telemetry.
- **Instrument Density & Optical Precision:** Deep midnight obsidian surfaces eliminate ambient glare and visual fatigue. Hairline borders, precision grid alignment, and micro-machined controls establish an institutional, flight-tested digital workspace.
- **Glassmorphic Obsidian Planes:** Deep blue-black translucent decks (`#0a0e17`, `#0f131c`) host muted internal glows, razor-thin specular bevels, and directional accents without introducing visual noise.

## Colors

The chromatic structure orchestrates a deliberate tri-vector telemetry hierarchy atop deep midnight obsidian depths:

- **Primary (`#f5c042` / Cyber-Gold):** The authoritative anchor. Governs primary commands, master toggles, active focus targets, running timers, and prominent metrics. Secondary gold (`#e5a93b`) supplies rich gradients and pressed-state contrasts.
- **Secondary (`#00e5ff` / Electric Cyan):** Dedicated to technical data streams, system ping acknowledgments, navigation indicators, sub-metrics, and secondary operational telemetry.
- **Tertiary (`#ff3366` / Laser Crimson):** High-priority exceptions, system overrides, destructive alerts, emergency disconnect triggers, and critical threshold monitors.
- **Neutral & Structural Foundations:**
  - `canvas-root`: `#0a0e17` (void black baseline)
  - `surface-deck`: `#0f131c` (structural card and tool panels)
  - `surface-elevated`: `#181b25` (floating overlays, modals, and raised consoles)
  - `surface-bright`: `#262a34` (interactive control backgrounds)
- **Text & Telemetry Typography Tones:**
  - Primary Readouts: `#f8fafc` (high-contrast ice white)
  - Secondary Readouts: `#dfe2ef` (cool optical white)
  - Metadata & Labels: `#bac9cc` (muted technical slate)
  - Inactive / Grid Legends: `#475569` (dimmed channel slate)

## Typography

The type system balances **Inter** for clean content layout and fast hierarchical scanning with **JetBrains Mono** for mission telemetry, timestamps, status payloads, and tabular data:

- **Hierarchy & Proportions:** Major HUD headers use Inter with tight tracking (`-0.02em`) to evoke structural rigidity. Micro-labels and telemetry banners employ JetBrains Mono in uppercase with wide letter-spacing (`+0.06em` to `+0.08em`) to resemble tactical avionics displays.
- **Tabular Alignment:** All numerical outputs, status counts, timestamps, and grid addresses must enforce tabular figures (`font-variant-numeric: tabular-nums`) to prevent optical shifting during live feed updates.

## Layout & Spacing

The layout is built around a dense, high-efficiency command grid modeled for intensive cockpit workflows:

- **Deck Architecture:**
  - **Left Navigation Rail:** Fixed width at `240px`, collapsible into a `64px` icon dock.
  - **Telemetry Matrix (Central Deck):** Fluid 12-column layout partitioned into primary tactical cards and live diagnostic feeds.
  - **Auxiliary Telemetry Dock (Right Inspector):** Contextual side pane at `320px` for detail inspections, log streams, and sensor configs.
- **Spacing Cadence:** Adheres to a strict 4px/8px structural step. High-density arrays (data cells, status badges) leverage `space-xs` (4px) and `space-sm` (8px). Structural containment zones utilize `space-lg` (20px) to maintain clarity across dense visual modules.

## Elevation & Depth

Visual hierarchy does not use diffuse dropshadows. Depth is built through stacked translucent obsidian planes, specular inner edges, and laser-precise directional photon glows:

- **Level 0 (Root Deck):** Solid `#0a0e17` background with a subtle ambient radial glow centered behind primary displays (`rgba(245, 192, 66, 0.03)`).
- **Level 1 (Telemetry Panels & Containers):** Translucent backdrop (`#0f131c` at 80% opacity) with `backdrop-filter: blur(16px)` and a composite ghost border (`1px solid rgba(245, 192, 66, 0.12)`).
- **Level 2 (Active/Hover Cards & Context Panels):** Surface `#181b25` at 90% opacity, bordered by `rgba(245, 192, 66, 0.35)` with an ambient gold perimeter wash: `box-shadow: 0 0 20px -4px rgba(245, 192, 66, 0.15), 0 8px 32px rgba(0, 0, 0, 0.6)`.
- **Level 3 (Focused Instruments & Live Telemetry Triggers):** Photonic bloom state: dual-layer glow featuring a 1px solid accent ring surrounded by an external Gaussian halo (`0 0 16px rgba(245, 192, 66, 0.45)` for primary, or `rgba(0, 229, 255, 0.45)` for cyan telemetry channels).

## Shapes

The design system maintains an engineered, machined silhouette with compact rounding. Corners suggest CNC-milled instrument chassis rather than soft consumer surfaces:

- **Containers & Deck Cards:** `0.5rem` (8px) corner radius for clean architectural grouping.
- **Inputs, Buttons, and System Chips:** `0.25rem` (4px) corner radius to ensure maximum click area and sharp tactical discipline.
- **Status Beads & Live Pulse Nodes:** Fully circular (`rounded-full`) for omnidirectional optical emission.

## Components

### Buttons & Tactical Controls
- **Primary Trigger (Master Action):** High-saturation cyber-gold (`#f5c042`) fill paired with void obsidian (`#0a0e17`) bold typography. Emits a localized amber-gold bloom (`0 0 16px rgba(245, 192, 66, 0.35)`). Active state shifts to `#e5a93b` with a `0.98` scale micro-compression.
- **Secondary Telemetry Trigger:** Dark chassis (`rgba(0, 229, 255, 0.08)`) with cyan border (`1px solid rgba(0, 229, 255, 0.3)`) and electric cyan text (`#00e5ff`). On hover, border illuminates to `#00e5ff` with a cyan wash (`rgba(0, 229, 255, 0.16)`).
- **Emergency / Terminate Trigger:** Tinted crimson frame (`rgba(255, 51, 102, 0.2)`), crimson typography (`#ff3366`), and an emergency scarlet glow on hover (`0 0 14px rgba(255, 51, 102, 0.3)`).

### Input Fields & Command Omnibar
- **Chassis:** Sunken `#0a0e17` base with an inset shadow (`inset 0 1px 3px rgba(0,0,0,0.8)`). Frame styled with `1px solid rgba(245, 192, 66, 0.15)`. Muted slate placeholder text (`#475569`).
- **Focus Mode:** Border snaps to `#f5c042` with an internal ambient refraction (`box-shadow: inset 0 0 8px rgba(245, 192, 66, 0.18)`).

### Chips & Telemetry Status Badges
- **Gold Mode (Active Channel):** Background `rgba(245, 192, 66, 0.12)`, border `rgba(245, 192, 66, 0.4)`, text `#f5c042`.
- **Cyan Mode (Data Link / Sync):** Background `rgba(0, 229, 255, 0.1)`, border `rgba(0, 229, 255, 0.35)`, text `#00e5ff`.
- **Crimson Mode (Alert / Overload):** Background `rgba(255, 51, 102, 0.12)`, border `rgba(255, 51, 102, 0.45)`, text `#ff3366`.

### Cards & Telemetry Deck Panels
- **Chassis Structure:** `#0f131c` glass base, `backdrop-filter: blur(16px)`, surrounded by a 1px border (`rgba(255, 255, 255, 0.05)` along top/left edges, `rgba(245, 192, 66, 0.15)` along bottom/right).
- **Card Eyebrow:** Monospaced label with right-aligned status node (cyan pulse for live data, gold for manual override).

### Checkboxes, Toggles & Radios
- **Checkboxes:** 16x16mm instrument frame with 2px radius. Unchecked: `#0a0e17` fill with slate border. Checked: cyber-gold (`#f5c042`) fill with an obsidian checkmark and faint amber aura.
- **Segmented Mode Switchers:** Recessed obsidian trench (`#0a0e17`). The active segment surfaces as `#181b25` topped with a sharp 1px cyber-gold rim and crisp `#f5c042` monospaced label.